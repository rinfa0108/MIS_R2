-- phpMyAdmin SQL Dump
-- version 3.3.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 05, 2013 at 02:17 AM
-- Server version: 5.1.50
-- PHP Version: 5.3.14

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mis_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `mis_agents`
--
-- Creation: Dec 05, 2013 at 02:15 AM
-- Last update: Dec 05, 2013 at 02:15 AM
--

DROP TABLE IF EXISTS `mis_agents`;
CREATE TABLE IF NOT EXISTS `mis_agents` (
  `AGENTS_ID` int(20) NOT NULL AUTO_INCREMENT,
  `BRANCH_ID` int(20) DEFAULT NULL,
  `AGENTS_NAME` varchar(150) NOT NULL,
  `AGENTS_CONTACTNUMBER` varchar(20) DEFAULT NULL,
  `AGENTS_ADDRESS` varchar(255) NOT NULL,
  `AGENTS_REMARKS` varchar(255) DEFAULT NULL,
  `AGENTS_DATECREATED` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`AGENTS_ID`),
  UNIQUE KEY `BRANCH_ID` (`BRANCH_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mis_agents`
--


-- --------------------------------------------------------

--
-- Table structure for table `mis_applicants_additionalinfo`
--
-- Creation: Dec 04, 2013 at 01:33 AM
-- Last update: Dec 04, 2013 at 01:33 AM
--

DROP TABLE IF EXISTS `mis_applicants_additionalinfo`;
CREATE TABLE IF NOT EXISTS `mis_applicants_additionalinfo` (
  `APPLICANTS_ADDITIONALINFO_ID` int(20) NOT NULL AUTO_INCREMENT,
  `APPLICANTS_PERSONAL_DATA_ID` int(20) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_ABROADRELATIVES_FULLNAME` varchar(255) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_ABROADRELATIVES_COUNTRY` varchar(100) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_ABROADRELATIVES_JOBDESC` varchar(155) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_MEDICATION_ILLNESS` varchar(255) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_MEDICATION_ILLNESSWHEN` varchar(50) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_HOSPITALIZED_ILLNESS` varchar(255) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_DATELASTCHILDDEVLIVERY` varchar(50) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_HOSPITAL_OPERATION` varchar(255) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_HOSPITAL_OPERATIONWHEN` varchar(50) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_REMARKS` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`APPLICANTS_ADDITIONALINFO_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mis_applicants_additionalinfo`
--


-- --------------------------------------------------------

--
-- Table structure for table `mis_applicants_additionalinfo_relatives`
--
-- Creation: Dec 04, 2013 at 01:26 AM
-- Last update: Dec 04, 2013 at 01:26 AM
--

DROP TABLE IF EXISTS `mis_applicants_additionalinfo_relatives`;
CREATE TABLE IF NOT EXISTS `mis_applicants_additionalinfo_relatives` (
  `APPLICANTS_ADDITIONALINFO_RELATIVES_ID` int(20) NOT NULL AUTO_INCREMENT,
  `APPLICANTS_PERSONAL_DATA_ID` int(20) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_RELATIVES_FULLNAME` int(255) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_RELATIVES_RELATIONSHIP` int(155) DEFAULT NULL,
  `APPLICANTS_ADDITIONALINFO_RELATIVES_POSITIONRANK` varchar(155) DEFAULT NULL,
  PRIMARY KEY (`APPLICANTS_ADDITIONALINFO_RELATIVES_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mis_applicants_additionalinfo_relatives`
--


-- --------------------------------------------------------

--
-- Table structure for table `mis_applicants_dailystatus`
--
-- Creation: Dec 04, 2013 at 11:33 PM
-- Last update: Dec 04, 2013 at 11:33 PM
--

DROP TABLE IF EXISTS `mis_applicants_dailystatus`;
CREATE TABLE IF NOT EXISTS `mis_applicants_dailystatus` (
  `APPLICANTS_DAILYSTATUS_ID` int(20) NOT NULL AUTO_INCREMENT,
  `APPLICANTS_PERSONAL_DATA_ID` int(20) NOT NULL,
  `AGENTBRANCH_ID` int(10) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_CONTACTNUMBER` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_APPIN` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_MEDICALDATE` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_MEDICALRESULT` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_NBI` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_NBIRR` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_TRAINING` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_PDOS` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_TESDA` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_OWWA` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_VISA_DATEISSUE` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_VISA_DATEEXPIRE` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_STAMPING_FILE` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_STAMPING_RELEASE` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_CONTRACTIN` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_PROCESSDATE` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_BOOKDATE` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_DEPLOYEDDATE` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_REMARKS` varchar(255) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_ENDCONTRACT_DATE` varchar(255) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_ISARCHIVE` varchar(1) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_DATECREATED` varchar(50) DEFAULT NULL,
  `APPLICANTS_DAILYSTATUS_DATEUPDATED` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`APPLICANTS_DAILYSTATUS_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mis_applicants_dailystatus`
--


-- --------------------------------------------------------

--
-- Table structure for table `mis_applicants_education`
--
-- Creation: Dec 04, 2013 at 01:22 AM
-- Last update: Dec 04, 2013 at 01:22 AM
--

DROP TABLE IF EXISTS `mis_applicants_education`;
CREATE TABLE IF NOT EXISTS `mis_applicants_education` (
  `APPLICANTS_EDUCATION_ID` int(20) NOT NULL AUTO_INCREMENT,
  `APPLICANTS_PERSONAL_DATA_ID` int(20) DEFAULT NULL,
  `APPLICANTS_EDUCATION_ELEM_SCHOOL` varchar(155) DEFAULT NULL,
  `APPLICANTS_EDUCATION_ELEM_COURSEDEGREE` varchar(155) DEFAULT NULL,
  `APPLICANTS_EDUCATION_ELEM_YEARATTENDED` varchar(50) DEFAULT NULL,
  `APPLICANTS_EDUCATION_HS_SCHOOL` varchar(155) DEFAULT NULL,
  `APPLICANTS_EDUCATION_HS_COURSEDEGREE` varchar(155) DEFAULT NULL,
  `APPLICANTS_EDUCATION_HS_YEARATTENDED` varchar(50) DEFAULT NULL,
  `APPLICANTS_EDUCATION_VOCATIONAL_SCHOOL` varchar(155) DEFAULT NULL,
  `APPLICANTS_EDUCATION_VOCATIONAL_COURSEDEGREE` varchar(155) DEFAULT NULL,
  `APPLICANTS_EDUCATION_VOCATIONAL_YEARATTENDED` varchar(50) DEFAULT NULL,
  `APPLICANTS_EDUCATION_COLLEGE_SCHOOL` varchar(155) DEFAULT NULL,
  `APPLICANTS_EDUCATION_COLLEGE_COURSEDEGREE` varchar(155) DEFAULT NULL,
  `APPLICANTS_EDUCATION_COLLEGE_YEARATTENDED` varchar(50) DEFAULT NULL,
  `APPLICANTS_EDUCATION_OTHERSKILLS_SCHOOL` varchar(155) DEFAULT NULL,
  `APPLICANTS_EDUCATION_OTHERSKILLS_COURSEDEGREE` varchar(155) DEFAULT NULL,
  `APPLICANTS_EDUCATION_OTHERSKILLS_YEARATTENDED` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`APPLICANTS_EDUCATION_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mis_applicants_education`
--


-- --------------------------------------------------------

--
-- Table structure for table `mis_applicants_family_data`
--
-- Creation: Dec 04, 2013 at 01:02 AM
-- Last update: Dec 04, 2013 at 01:02 AM
-- Last check: Dec 04, 2013 at 01:02 AM
--

DROP TABLE IF EXISTS `mis_applicants_family_data`;
CREATE TABLE IF NOT EXISTS `mis_applicants_family_data` (
  `APPLICANTS_FAMILY_DATA_ID` int(10) NOT NULL AUTO_INCREMENT,
  `APPLICANTS_PERSONAL_DATA_ID` int(20) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_MARITALSTATUS` int(1) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_NOOFCHILDREN` varchar(2) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_CHILDRENAGES` varchar(50) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_SPOUSEFULLNAME` varchar(255) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_FATHERSFULLNAME` varchar(255) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_MOTHERSFULLNAME` varchar(255) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_SPOUSETELNO` varchar(50) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_FATHERSTELNO` varchar(50) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_MOTHERSTELNO` varchar(50) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_SPOUSEOCCUPATION` varchar(255) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_FATHERSOCCUPATION` varchar(255) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_MOTHERSOCCUPATION` varchar(255) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_HOWMANYBROTHER` varchar(5) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_HOWMANYSISTERS` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`APPLICANTS_FAMILY_DATA_ID`),
  KEY `APPLICANTS_PERSONAL_DATA_ID` (`APPLICANTS_PERSONAL_DATA_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mis_applicants_family_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `mis_applicants_family_data_siblings`
--
-- Creation: Dec 04, 2013 at 01:10 AM
-- Last update: Dec 04, 2013 at 01:10 AM
--

DROP TABLE IF EXISTS `mis_applicants_family_data_siblings`;
CREATE TABLE IF NOT EXISTS `mis_applicants_family_data_siblings` (
  `APPLICANTS_FAMILY_DATA_SIBLINGS_ID` int(20) NOT NULL AUTO_INCREMENT,
  `APPLICANTS_PERSONAL_DATA_ID` int(20) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_SIBLINGS_FULLNAME` varchar(255) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_SIBLINGS_TELNO` varchar(50) DEFAULT NULL,
  `APPLICANTS_FAMILY_DATA_SIBLINGS_OCCUPATION` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`APPLICANTS_FAMILY_DATA_SIBLINGS_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mis_applicants_family_data_siblings`
--


-- --------------------------------------------------------

--
-- Table structure for table `mis_applicants_maritalstatus_selector`
--
-- Creation: Dec 04, 2013 at 12:47 AM
-- Last update: Dec 04, 2013 at 12:48 AM
--

DROP TABLE IF EXISTS `mis_applicants_maritalstatus_selector`;
CREATE TABLE IF NOT EXISTS `mis_applicants_maritalstatus_selector` (
  `APPLICANTS_PERSONAL_MARITALSTATUS_ID` int(10) NOT NULL AUTO_INCREMENT,
  `APPLICANTS_PERSONAL_MARITALSTATUS_VALUE` varchar(155) NOT NULL,
  PRIMARY KEY (`APPLICANTS_PERSONAL_MARITALSTATUS_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `mis_applicants_maritalstatus_selector`
--

INSERT INTO `mis_applicants_maritalstatus_selector` (`APPLICANTS_PERSONAL_MARITALSTATUS_ID`, `APPLICANTS_PERSONAL_MARITALSTATUS_VALUE`) VALUES
(1, 'Single'),
(2, 'Married'),
(3, 'Separated'),
(4, 'Widowed');

-- --------------------------------------------------------

--
-- Table structure for table `mis_applicants_personal_data`
--
-- Creation: Dec 04, 2013 at 12:43 AM
-- Last update: Dec 04, 2013 at 12:43 AM
--

DROP TABLE IF EXISTS `mis_applicants_personal_data`;
CREATE TABLE IF NOT EXISTS `mis_applicants_personal_data` (
  `APPLICANTS_PERSONAL_DATA_ID` int(20) NOT NULL AUTO_INCREMENT,
  `APPLICANTS_PERSONAL_DATA_DESIRED_POSITION` varchar(150) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_RELIGION` varchar(100) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_AGE` varchar(2) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_OTHERSKILLS` varchar(255) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_EXABROAD` int(1) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_EXABROAD_YEARS` varchar(2) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_COUNTRY_ABROAD` varchar(255) DEFAULT NULL,
  `APPLICANTS_PERSONAL_DATA_FIRSTNAME` varchar(155) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_MIDDLENAME` varchar(155) DEFAULT NULL,
  `APPLICANTS_PERSONAL_DATA_LASTNAME` varchar(155) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_HEIGHT` varchar(5) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_WEIGHT` varchar(10) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_GENDER` varchar(10) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_ADDRESS` varchar(350) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_TELEPHONE` varchar(20) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_CELLPHONE` varchar(20) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_DATEOFBIRTH` varchar(20) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_PLACEOFBIRTH` varchar(255) NOT NULL,
  `APPLICANTS_PERSONAL_DATA_DATECREATED` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`APPLICANTS_PERSONAL_DATA_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mis_applicants_personal_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `mis_applicants_personal_data_gender_selector`
--
-- Creation: Dec 04, 2013 at 12:50 AM
-- Last update: Dec 04, 2013 at 12:50 AM
--

DROP TABLE IF EXISTS `mis_applicants_personal_data_gender_selector`;
CREATE TABLE IF NOT EXISTS `mis_applicants_personal_data_gender_selector` (
  `APPLICANTS_PERSONAL_DATA_GENDER_SELECTOR_ID` int(2) NOT NULL AUTO_INCREMENT,
  `APPLICANTS_PERSONAL_DATA_GENDER_SELECTOR_VALUE` varchar(50) NOT NULL,
  PRIMARY KEY (`APPLICANTS_PERSONAL_DATA_GENDER_SELECTOR_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mis_applicants_personal_data_gender_selector`
--

INSERT INTO `mis_applicants_personal_data_gender_selector` (`APPLICANTS_PERSONAL_DATA_GENDER_SELECTOR_ID`, `APPLICANTS_PERSONAL_DATA_GENDER_SELECTOR_VALUE`) VALUES
(1, 'Male'),
(2, 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `mis_applicants_workexperience`
--
-- Creation: Dec 04, 2013 at 01:13 AM
-- Last update: Dec 04, 2013 at 01:13 AM
--

DROP TABLE IF EXISTS `mis_applicants_workexperience`;
CREATE TABLE IF NOT EXISTS `mis_applicants_workexperience` (
  `APPLICANTS_WORKEXPERIENCE_ID` int(20) NOT NULL AUTO_INCREMENT,
  `APPLICANTS_PERSONAL_DATA_ID` int(20) DEFAULT NULL,
  `APPLICANTS_WORKEXPERIENCE_COMPANY` varchar(255) DEFAULT NULL,
  `APPLICANTS_WORKEXPERIENCE_COMPANYADDR` varchar(255) DEFAULT NULL,
  `APPLICANTS_WORKEXPERIENCE_POSITION` varchar(155) DEFAULT NULL,
  `APPLICANTS_WORKEXPERIENCE_FROM` varchar(155) DEFAULT NULL,
  `APPLICANTS_WORKEXPERIENCE_TO` int(155) DEFAULT NULL,
  PRIMARY KEY (`APPLICANTS_WORKEXPERIENCE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mis_applicants_workexperience`
--


-- --------------------------------------------------------

--
-- Table structure for table `mis_branch`
--
-- Creation: Dec 04, 2013 at 11:21 PM
-- Last update: Dec 04, 2013 at 11:21 PM
--

DROP TABLE IF EXISTS `mis_branch`;
CREATE TABLE IF NOT EXISTS `mis_branch` (
  `BRANCH_ID` int(10) NOT NULL AUTO_INCREMENT,
  `BRANCH_CODENUMBER` varchar(20) NOT NULL,
  `BRANCH_NAME` varchar(255) NOT NULL,
  `BRANCH_ADDRESS` varchar(255) NOT NULL,
  `BRANCH_REMARKS` varchar(255) DEFAULT NULL,
  `BRANCH_DATECREATED` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`BRANCH_ID`),
  UNIQUE KEY `AGENTBRANCH_CODENUMBER` (`BRANCH_CODENUMBER`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mis_branch`
--


-- --------------------------------------------------------

--
-- Table structure for table `mis_sys_modules`
--
-- Creation: Dec 04, 2013 at 01:36 AM
-- Last update: Dec 05, 2013 at 01:46 AM
--

DROP TABLE IF EXISTS `mis_sys_modules`;
CREATE TABLE IF NOT EXISTS `mis_sys_modules` (
  `SYS_MODULES_ID` int(10) NOT NULL AUTO_INCREMENT,
  `SYS_MODULES_NAME` varchar(100) NOT NULL,
  `SYS_MODULES_DESCRIPTION` varchar(100) DEFAULT NULL,
  `SYS_MODULES_CONTROLLERNAME` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`SYS_MODULES_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `mis_sys_modules`
--

INSERT INTO `mis_sys_modules` (`SYS_MODULES_ID`, `SYS_MODULES_NAME`, `SYS_MODULES_DESCRIPTION`, `SYS_MODULES_CONTROLLERNAME`) VALUES
(1, 'Dashboard', 'Main Page', 'Index'),
(2, 'Agent Branch', 'Company agent of branch', 'Agentbranch'),
(3, 'Admin', 'Administrator Page', 'Admin'),
(4, 'Applicants Data ', 'Applicants Info data page', 'Applicantdata');

-- --------------------------------------------------------

--
-- Table structure for table `mis_sys_users`
--
-- Creation: Nov 24, 2013 at 11:35 PM
-- Last update: Nov 25, 2013 at 12:59 AM
--

DROP TABLE IF EXISTS `mis_sys_users`;
CREATE TABLE IF NOT EXISTS `mis_sys_users` (
  `SYS_USERS_ID` int(10) NOT NULL AUTO_INCREMENT,
  `SYS_USERS_USERNAME` varchar(100) NOT NULL,
  `SYS_USERS_PASSWORD` varchar(150) NOT NULL,
  `SYS_USERS_FULLNAME` varchar(150) NOT NULL,
  `SYS_USERS_GROUP_ID` int(2) NOT NULL,
  `SYS_USERS_DATE_CREATED` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`SYS_USERS_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mis_sys_users`
--

INSERT INTO `mis_sys_users` (`SYS_USERS_ID`, `SYS_USERS_USERNAME`, `SYS_USERS_PASSWORD`, `SYS_USERS_FULLNAME`, `SYS_USERS_GROUP_ID`, `SYS_USERS_DATE_CREATED`) VALUES
(1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'administrator', 1, '2013-11-24 23:41:49');

-- --------------------------------------------------------

--
-- Table structure for table `mis_user_group`
--
-- Creation: Nov 24, 2013 at 11:40 PM
-- Last update: Dec 05, 2013 at 01:43 AM
--

DROP TABLE IF EXISTS `mis_user_group`;
CREATE TABLE IF NOT EXISTS `mis_user_group` (
  `USER_GROUP_ID` int(10) NOT NULL AUTO_INCREMENT,
  `USER_GROUP_NAME` varchar(100) NOT NULL,
  `USER_GROUP_DESCRIPTION` varchar(150) NOT NULL,
  PRIMARY KEY (`USER_GROUP_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mis_user_group`
--

INSERT INTO `mis_user_group` (`USER_GROUP_ID`, `USER_GROUP_NAME`, `USER_GROUP_DESCRIPTION`) VALUES
(1, 'Admintrator', 'Application Root Users'),
(2, 'Agent', 'Company Agents'),
(3, 'Accounting', 'Company Accounting Dept.');

-- --------------------------------------------------------

--
-- Table structure for table `mis_user_group_restriction`
--
-- Creation: Nov 24, 2013 at 11:40 PM
-- Last update: Nov 24, 2013 at 11:40 PM
--

DROP TABLE IF EXISTS `mis_user_group_restriction`;
CREATE TABLE IF NOT EXISTS `mis_user_group_restriction` (
  `USER_GROUP_RESTRICTION_ID` int(10) NOT NULL AUTO_INCREMENT,
  `USER_GROUP_RESTRICTION_USER_GROUP_ID` int(10) NOT NULL,
  `USER_GROUP_RESTRICTION_MODULE_ID` int(10) NOT NULL,
  `USER_GROUP_RESTRICTION_ISENABLED` int(1) NOT NULL,
  PRIMARY KEY (`USER_GROUP_RESTRICTION_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mis_user_group_restriction`
--

